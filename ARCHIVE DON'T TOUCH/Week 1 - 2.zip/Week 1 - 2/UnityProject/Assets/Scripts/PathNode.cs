﻿using UnityEngine;
using System.Collections;

public class PathNode : MonoBehaviour {
    public PathNode nextNode;
    public float SpeedToThis = 15;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
