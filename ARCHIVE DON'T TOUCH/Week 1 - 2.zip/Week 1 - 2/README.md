OctoPonies
==========

Musical Platform game


Pensez à bien installer : http://unity3d.com/unity/download

Voici le but du projet : http://www.youtube.com/watch?v=NExRAajiM_o

Groupe :

Gameplay

Stan : Stanislas.mur@gmail.com
Kevin : kevin.havrez@gmail.com
Jerome : armadon13127@gmail.com

Design

Ludo : ludovic.romano@live.fr
Romain : romain.lelievre93@gmail.com
Yuxing : unearthnight@gmail.com


